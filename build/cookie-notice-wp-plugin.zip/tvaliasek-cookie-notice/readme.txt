=== Plugin Name ===
Contributors: tvaliasek
Donate link: 
Tags: tvaliasek-cookie-notice
Requires at least: 
Tested up to: 
Stable tag: 
License: MIT


== Description ==


== Installation ==


== Changelog ==

= 1.0 =
